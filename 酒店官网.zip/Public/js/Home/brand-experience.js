var Wyndham = Wyndham || {};
Wyndham.brandExperience = Wyndham.brandExperience || {};

Wyndham.brandExperience = {
	slideShowHome : function() {
		
	var $homeBG	= $('body');
	$homeBG = $("body").attr("id",'homeBody');
		
		// Add Main image Backgrounds Turned off in CSS
		//$homeBG.prepend('<ul class="slider_window"><li><div id="lakeBody"></div><div id="lakeBG"></div></li><li><div id="beachBody"></div><div id="beachBG"></div></li><li><div id="mountainBody"></div><div id="mountainsBG"></div></li><li><div id="cityBody"></div><div id="cityBG"></div></li><li><div id="genericBody"></div></li></ul>');
		
		$homeBG.prepend('<ul class="slider_window"><li><div id="genericBody"></div></li><li><div id="cityBody"></div><div id="cityBG"></div></li><li><div id="beachBody"></div><div id="beachBG"></div></li><li><div id="lakeBody"></div><div id="lakeBG"></div></li></ul>');
		
		
		// This is the Hero slide show
		// this will controll the background change
		// When slide switched two bg images will fade in and out
		
		// Home Page Slideshow
		var $sliderWindow = $(".slider_window");
		
		$sliderWindow.each(function(index) {
			$(this).cycle({
				fx: 'fade', 
				continuous: 0,
				timeout: 4000,
				speedIn: 1000,
				speedOut: 1000,
				pager: '.center-wrap',
				next:null,
				slideExpr: 'li',
				pauseOnPagerHover: true,
				pagerAnchorBuilder: function(i) {
					if (index == 0)
						// for first slideshow, return a new anchro
						return '<a href="#">'+(i+1)+'</a>';
					// for 2nd slideshow, select the anchor created previously
					return '.center-wrap a:eq('+i+')';
				},
				before: function(){
					var $sliderWindowli = $(".slider_window li");
						$sliderWindowli.css('width', '100%');
						$sliderWindowli.children().css('width', '100%');
					
					var $window = $(window);
					$window.resize( function(){
						//console.log("resized");
						var $sliderWindowli = $(".slider_window li");
						$sliderWindowli.css('width', '100%');
						$sliderWindowli.children().css('width', '100%');
					});
				}
			});
		});
		
		var $window = $(window);
		$window.resize( function(){
			//console.log("resized");
			var $sliderWindowli = $(".slider_window li");
			$sliderWindowli.children().css('width', '100%');
		});
		
		// CTA scroller
		var $ul = $('ul.long_div');
		
		$ul.jcarousel({
			auto: 0,
			wrap: "circular",
			visible: 3,
			start:1,
			scroll: 1,
			animation: "slow",
			initCallback : function () {
			  var arrows = $('div.jcarousel-prev, div.jcarousel-next');
			  var ul = $('ul.long_div');
			  var espotAmount = ul.find('li.espot');
			  arrows.show();
			}
		});
		
	
	},
	// Brand Experience slide shows
	slideShowBrandExperience : function(){
		// Wyndham Experience page
		var $sliderDiv = $(".wx_slider_window");
		
		//$sliderDiv.after('<div id="pagination">');
		$sliderDiv.cycle({
			fx: 'fade', 
			continuous: 0, 
			speed: 1000,
			pager: '#pagination',
			pause:true,
			next:null,
			pauseOnPagerHover:true,
			pagerAnchorBuilder: function(idx, slide) { 				
				// callback fn that creates a thumbnail to use as pager anchor
				if(idx === 0)
					return '<div class="hotelResort"><p>Well suited to all your travel needs.</p></div>';
				else if (idx === 1)
					return '<div class="hotelGrand"><p>Our finest and most sophisticated collection of hotels.</p></div>'; 
				else if (idx === 2)
					return '<div class="hotelGarden"><p>Inviting, comfortable hotels with efficient Wyndham amenities.</p></div>'; 	
			}
		});
		
		// Brand Experience page
		var $bxSlider = $('.bx_slider_window');		
		$bxSlider.after('<div id="pageDots">');
		$bxSlider.cycle({
			fx: 'fade',
			continuous: 0, 
			speed: 1000,
			pager: '#pageDots',
			pause:true,
			next:null,
			pauseOnPagerHover:true
		});
	},
	// This is the hide/show of the Brand experience page.
	accordian : function() {
		
		var $hotelDescription = $('div.bxContent div.hotelDescriptions'),
			$bxResults = $('div.bxContent div.results_meta'),
			$expandLink = $('div.bxContent div.expandLink'),
			$closedCheck = true;
			
			$expandLink.click( function(){
				if($closedCheck){
					$hotelDescription.slideDown(300);
					$bxResults.fadeIn('fast');
					$expandLink.css({backgroundPosition: '0px -47px'}).text('Hide Wyndham Hotel and Resorts');
					$closedCheck = false;
				}
				else{
					$hotelDescription.slideUp(300);
					$bxResults.fadeOut('fast');
					$expandLink.css({backgroundPosition: '0px 0px'}).text('Show Wyndham Hotel and Resorts');
					$closedCheck = true;
				}
			});
	
	}
}

//Run automatically
$(document).ready(function() {
	Wyndham.brandExperience.slideShowHome();
	Wyndham.brandExperience.slideShowBrandExperience();
	Wyndham.brandExperience.accordian();	
});